from django.shortcuts import render
from django.http import HttpResponse


def delete_products(request):
    #return HttpResponse("Hello, world!", status=200)  # Default is 200 if not specified
    return render(request, 'delete_products.html')
