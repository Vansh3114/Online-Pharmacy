from django.apps import AppConfig


class DeleteProductsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'delete_products'
