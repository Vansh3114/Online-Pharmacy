from django.contrib import admin
from .models import Medicines

admin.site.register(Medicines)