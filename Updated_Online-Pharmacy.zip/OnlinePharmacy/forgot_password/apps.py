from django.apps import AppConfig


class forgot_passwordConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'forgot_password'
