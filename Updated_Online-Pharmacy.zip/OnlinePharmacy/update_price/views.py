from django.shortcuts import render

def update_price(request):
    return render(request, 'update_price.html')

