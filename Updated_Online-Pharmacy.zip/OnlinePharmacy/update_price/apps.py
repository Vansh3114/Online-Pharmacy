from django.apps import AppConfig


class UpdatePriceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'update_price'
