from django.apps import AppConfig


class AdminTasksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'admin_tasks'
